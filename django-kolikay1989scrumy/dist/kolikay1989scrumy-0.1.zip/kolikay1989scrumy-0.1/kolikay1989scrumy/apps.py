from django.apps import AppConfig


class Kolikay1989ScrumyConfig(AppConfig):
    name = 'kolikay1989scrumy'
